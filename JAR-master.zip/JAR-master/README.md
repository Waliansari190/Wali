![logo](https://i.postimg.cc/x9v80djN/20200606-020927.jpg) 

## Commands
git clone https://github.com/Err0r-ICA/JAR <br>
cd JAR <br>
sh JAR <br>

## Screenshot 
![Screenshot](https://i.postimg.cc/LHLctpKF/Screenshot-20200425-143306-Termux.jpg) 

### My Accounts
* [TELEGRAM](https://t.me/kalit3rmux)
* [FACEBOOK](https://www.facebook.com/termuxxhacking)
* [INSTAGRAM](https://instagram.com/termux_hacking)
